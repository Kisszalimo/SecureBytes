package hu.unideb.inf;

public class Main {
    public static void main(String[] args) {
        MainApp.main(args);
    }
}
